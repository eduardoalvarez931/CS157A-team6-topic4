package teamproj;

public  abstract class Med {
	private int id;
	private String name;
	private String description;

	public Med() {};
	
	public Med(String name)
	{
		this.name = name;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}
}

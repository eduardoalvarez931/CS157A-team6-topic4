package teamproj;

public class TestElements {
	
	public TestElements(){}
	
	private boolean f25 = false;
	private boolean f50 = false;
	private boolean f1 = false;
	private boolean f2 = false;
	private boolean f3 = false;
	private boolean f4 = false;
	private boolean f6 = false;
	private boolean f8 = false;
	private boolean f10 = false;
	private boolean f12 = false;
	
	private int tinPitchMatch = 0;//tinnitus pitch match
	private int tinMatchType = 0;//tinnitus match type
	private int tinLoudMatch = 0;//tinnitus loudness match
	private int thresHearing = 0;//threshold of hearing (Th)
	private int thresHearTLs = 0;//threshold of hearing (TLs)
	
	private int WN = 0;
	
	//minimal masking level
	private int mr = 0;
	private int m_b = 0;
	private int mb_ = 0;
	
	private int sd = 0 ;
	
	private boolean l50 = false;
	private boolean l1 = false;
	private boolean l2 = false;
	private boolean l3 = false;
	private boolean l4 = false;
	private boolean l6 = false;
	private boolean l8 = false;
	private boolean l12 = false;
	private boolean ltp = false;
	
	private String comments = " ";

	public int getF25() {
		if(f25 == false) return 0;
		else return 1;
	}

	public int getF50() {
		if(f50 == false) return 0;
		else return 1;
	}

	public int getF1() {
		if(f1 == false) return 0;
		else return 1;
	}

	public int getF2() {
		if(f2 == false) return 0;
		else return 1;
	}

	public int getF3() {
		if(f3 == false) return 0;
		else return 1;
	}

	public int getF4() {
		if(f4 == false) return 0;
		else return 1;
	}

	public int getF6() {
		if(f6 == false) return 0;
		else return 1;
	}

	public int getF8() {
		if(f8 == false) return 0;
		else return 1;
	}

	public int getF10() {
		if(f10 == false) return 0;
		else return 1;
	}

	public int getF12() {
		if(f12 == false) return 0;
		else return 1;
	}

	public int getTinPitchMatch() {
		return tinPitchMatch;
	}

	public int getTinMatchType() {
		return tinMatchType;
	}

	public int getTinLoudMatch() {
		return tinLoudMatch;
	}

	public int getThresHearing() {
		return thresHearing;
	}

	public int getThresHearTLs() {
		return thresHearTLs;
	}

	public int getWN() {
		return WN;
	}

	public int getMr() {
		return mr;
	}

	public int getM_b() {
		return m_b;
	}

	public int getMb_() {
		return mb_;
	}

	public int getSd() {
		return sd;
	}

	public int getL50() {
		if(l50 == false) return 0;
		else return 1;
	}

	public int getL1() {
		if(l1 == false) return 0;
		else return 1;
	}

	public int getL2() {
		if(l2 == false) return 0;
		else return 1;
	}

	public int getL3() {
		if(l3 == false) return 0;
		else return 1;
	}

	public int getL4() {
		if(l4 == false) return 0;
		else return 1;
	}

	public int getL6() {
		if(l6 == false) return 0;
		else return 1;
	}

	public int getL8() {
		if(l8 == false) return 0;
		else return 1;
	}

	public int getL12() {
		if(l12 == false) return 0;
		else return 1;
	}

	public int getLtp() {
		if(ltp == false) return 0;
		else return 1;
	}

	public String getComments() {
		return comments;
	}

	public void setF25(boolean f25) {
		this.f25 = f25;
	}

	public void setF50(boolean f50) {
		this.f50 = f50;
	}

	public void setF1(boolean f1) {
		this.f1 = f1;
	}

	public void setF2(boolean f2) {
		this.f2 = f2;
	}

	public void setF3(boolean f3) {
		this.f3 = f3;
	}

	public void setF4(boolean f4) {
		this.f4 = f4;
	}

	public void setF6(boolean f6) {
		this.f6 = f6;
	}

	public void setF8(boolean f8) {
		this.f8 = f8;
	}

	public void setF10(boolean f10) {
		this.f10 = f10;
	}

	public void setF12(boolean f12) {
		this.f12 = f12;
	}

	public void setTinPitchMatch(int tinPitchMatch) {
		this.tinPitchMatch = tinPitchMatch;
	}

	public void setTinMatchType(int tinMatchType) {
		this.tinMatchType = tinMatchType;
	}

	public void setTinLoudMatch(int tinLoudMatch) {
		this.tinLoudMatch = tinLoudMatch;
	}

	public void setThresHearing(int thresHearing) {
		this.thresHearing = thresHearing;
	}

	public void setThresHearTLs(int thresHearTLs) {
		this.thresHearTLs = thresHearTLs;
	}

	public void setWN(int wN) {
		WN = wN;
	}

	public void setMr(int mr) {
		this.mr = mr;
	}

	public void setM_b(int m_b) {
		this.m_b = m_b;
	}

	public void setMb_(int mb_) {
		this.mb_ = mb_;
	}

	public void setSd(int sd) {
		this.sd = sd;
	}

	public void setL50(boolean l50) {
		this.l50 = l50;
	}

	public void setL1(boolean l1) {
		this.l1 = l1;
	}

	public void setL2(boolean l2) {
		this.l2 = l2;
	}

	public void setL3(boolean l3) {
		this.l3 = l3;
	}

	public void setL4(boolean l4) {
		this.l4 = l4;
	}

	public void setL6(boolean l6) {
		this.l6 = l6;
	}

	public void setL8(boolean l8) {
		this.l8 = l8;
	}

	public void setL12(boolean l12) {
		this.l12 = l12;
	}

	public void setLtp(boolean ltp) {
		this.ltp = ltp;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
}

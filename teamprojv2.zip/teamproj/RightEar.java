package teamproj;

public class RightEar extends TestElements{
	
	public RightEar() {}
}

package teamproj;

public class Generic extends Med {

	public Generic(String name) {
		super(name);
	}
}

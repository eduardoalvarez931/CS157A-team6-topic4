package teamproj;

public class MedicalAttributes {
	
	private int medID;
	private String medicationName;
	private String doseAmount;
	private String duration;
	private CatChemical catChem;
	private Disease disease;
	private Generic generic;
	private String action;
	private String application;
	private String usualDose;
	
	public MedicalAttributes(int medID)
	{
		this.medID = medID;
	}

	public int getMedID() {
		return medID;
	}

	public String getMedicationName() {
		return medicationName;
	}

	public String getDoseAmount() {
		return doseAmount;
	}

	public String getDuration() {
		return duration;
	}

	public CatChemical getCatChem() {
		return catChem;
	}

	public Disease getDisease() {
		return disease;
	}

	public Generic getGeneric() {
		return generic;
	}

	public String getAction() {
		return action;
	}

	public String getApplication() {
		return application;
	}

	public String getUsualDose() {
		return usualDose;
	}

	public void setMedID(int medID) {
		this.medID = medID;
	}

	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}

	public void setDoseAmount(String doseAmount) {
		this.doseAmount = doseAmount;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public void setCatChem(CatChemical catChem) {
		this.catChem = catChem;
	}

	public void setDisease(Disease disease) {
		this.disease = disease;
	}

	public void setGeneric(Generic generic) {
		this.generic = generic;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public void setUsualDose(String usualDose) {
		this.usualDose = usualDose;
	}
	
}

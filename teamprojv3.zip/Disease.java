package teamproj;

public class Disease extends Med {

	public Disease(String name) {
		super(name);
	}
}

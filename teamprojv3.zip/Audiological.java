package teamproj;

import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Connection;

public class Audiological{
	private RightEar rightEar;
	private LeftEar leftEar;
	private Patient patient;
	
	public void execute(Connection con)
	{
		
		
	}
	
}

package teamproj;

public class LeftEar extends TestElements {
	public LeftEar() {}
}

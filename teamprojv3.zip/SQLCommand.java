package teamproj;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLCommand {

	public static void saveToAudiological(LeftEar leftEar, RightEar rightEar) 
	{
		Statement stmt = SQLStartUp.startConnection();
		String insert = "INSERT INTO ";
		String audioTable = "Audiological";
		String values = "VALUES";
		try {
			 stmt.executeUpdate(insert+audioTable+values+"("+
					rightEar.getF25()+", " + leftEar.getF25()+", "+
					rightEar.getF50()+", " + leftEar.getF50()+", "+
					rightEar.getF1()+", " + leftEar.getF1()+", "+
					rightEar.getF2()+", " + leftEar.getF2()+", "+
					rightEar.getF3()+", " + leftEar.getF3()+", "+
					rightEar.getF4()+", " + leftEar.getF4()+", "+
					rightEar.getF6()+", " + leftEar.getF6()+", "+
					rightEar.getF8()+", " + leftEar.getF8()+", "+
					rightEar.getF10()+", " + leftEar.getF10()+", "+
					rightEar.getF12()+", " + leftEar.getF12()+", "+
					
					rightEar.getTinPitchMatch()+", " + rightEar.getTinMatchType()+", "+
					rightEar.getTinLoudMatch()+", " + rightEar.getThresHearing()+", "+
					rightEar.getThresHearTLs()+", " + 
					
					leftEar.getTinPitchMatch()+", " + leftEar.getTinMatchType()+", "+
					leftEar.getTinLoudMatch()+", " + leftEar.getThresHearing()+", "+
					leftEar.getThresHearTLs()+", " + 
					
					rightEar.getWN()+", " + leftEar.getWN()+", "+
					rightEar.getMr()+", " + leftEar.getMr()+", "+
					rightEar.getM_b()+", "+ leftEar.getM_b()+", "+
					rightEar.getMb_()+", "+ leftEar.getMb_()+", "+
					
					rightEar.getSd()+", "+leftEar.getSd()+", "+
					
					rightEar.getL50()+", "+rightEar.getL1()+", "+
					rightEar.getL2()+", "+rightEar.getL3()+", "+
					rightEar.getL4()+", "+rightEar.getL6()+", "+
					rightEar.getL8()+", "+rightEar.getL12()+", "+
					rightEar.getLtp()+", "+leftEar.getL50()+", "+
					leftEar.getL1()+", "+leftEar.getL2()+", "+
					leftEar.getL3()+", "+leftEar.getL4()+", "+
					leftEar.getL6()+", "+leftEar.getL8()+", "+
					leftEar.getL12()+", "+leftEar.getLtp()+");");
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}
}

package teamproj;

public class Patient {
	private String firstName;
	private String lastName;
	private int thcNumber;
	private Visit visit;
	
	public Patient(String fName, String lName, int thc)
	{
		firstName = fName;
		lastName = lName;
		thcNumber = thc;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public int getThcNumber() {
		return thcNumber;
	}

	public Visit getVisit() {
		return visit;
	}
}

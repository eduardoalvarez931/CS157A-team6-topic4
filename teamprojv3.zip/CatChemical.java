package teamproj;

public class CatChemical extends Med {

	public CatChemical(String name) 
	{
		super(name);
	}
}

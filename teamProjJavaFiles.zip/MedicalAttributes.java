package teamproj;

public class MedicalAttributes {
	
	private int medID;
	private String medicationName;
	private String doseAmount;
	private String duration;
	private CatChemical catChem;
	private Disease disease;
	private Generic generic;
	private String action;
	private String application;
	private String usualDose;
	
	
}

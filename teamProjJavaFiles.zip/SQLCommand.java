package teamproj;

public class SQLCommand {

	public static void save() {
		
	}
}
